import pandas as pd

def run(df):
    output = []
    # Remove duplicate rows
    df_cleaned = df.drop_duplicates()

    # Step 1: Display basic information about the dataset
    output.append("Dataset Overview:")
    output.append(str(df_cleaned.info()))  # Show data types, non-null counts, and memory usage
    output.append("\nFirst few rows of the dataset:")
    output.append(str(df_cleaned.head()))  # Display the first few rows for inspection

    # Step 2: Describe the dataset to understand numerical attributes
    output.append("\nSummary statistics for numerical columns:")
    output.append(str(df_cleaned.describe()))  # Show summary statistics for quantitative attributes

    # Step 3: Identify column types
    # Quantitative (Numerical) Columns: Typically continuous variables
    quantitative_columns = df_cleaned.select_dtypes(include=['float64', 'int64']).columns.tolist()

    # Categorical (Categorical/Qualitative) Columns: Typically non-numerical or discrete variables
    categorical_columns = df_cleaned.select_dtypes(include=['object']).columns.tolist()

    output.append(f"\nQuantitative Columns: {quantitative_columns}")
    output.append(f"Categorical/Qualitative Columns: {categorical_columns}")

    # Step 4: Check for any unwanted columns (columns with mostly missing values or redundant information)
    missing_data = df_cleaned.isnull().sum()
    output.append("\nMissing Data per Column:")
    output.append(str(missing_data))

    # Identify columns with more than 50% missing values (example criteria for removal)
    columns_to_remove = missing_data[missing_data > (0.5 * len(df_cleaned))].index.tolist()
    output.append(f"\nColumns to potentially remove (more than 50% missing values): {columns_to_remove}")

    # If there are unwanted columns, drop them
    if columns_to_remove:
        df_cleaned = df_cleaned.drop(columns=columns_to_remove)
        output.append(f"\nUpdated Dataset Shape after removing unwanted columns: {df_cleaned.shape}")
    else:
        output.append("\nNo columns were removed as all have sufficient data.")

    # Step 5: Display final column list after removing unwanted columns
    output.append("\nFinal Column List:")
    output.append(str(df_cleaned.columns.tolist()))

    return "\n".join(output)
