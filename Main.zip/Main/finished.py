import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression
import joblib
import numpy as np

# Modified function to be used with the GUI
def run(df):
    output = []
    # Features and target selection
    X = df.drop('charges', axis=1, errors='ignore')
    if 'charges' in df:
        y = df['charges']
    else:
        return "Error: Target variable 'charges' not found."

    # Preprocessing the categorical variables
    categorical_features = ['sex', 'smoker', 'region']
    numerical_features = ['age', 'bmi', 'children']

    # Define the ColumnTransformer to preprocess categorical and numerical features
    preprocessor = ColumnTransformer(
        transformers=[
            ('num', StandardScaler(), numerical_features),
            ('cat', OneHotEncoder(), categorical_features)
        ]
    )

    # Create a pipeline with preprocessing and regression model
    model_pipeline = Pipeline(steps=[
        ('preprocessor', preprocessor),
        ('regressor', LinearRegression())
    ])

    # Train the model using the entire dataset
    model_pipeline.fit(X, y)

    # Save the model to a file
    model_filename = 'insurance_model.pkl'
    joblib.dump(model_pipeline, model_filename)
    output.append(f"Model training complete and saved as '{model_filename}'")

    return "\n".join(output)

# Function to load the model and make predictions
def predict_insurance_cost(age, sex, bmi, children, smoker, region):
    # Load the trained model
    model = joblib.load('insurance_model.pkl')
    
    # Create a DataFrame for the input data
    input_data = pd.DataFrame({
        'age': [age],
        'sex': [sex],
        'bmi': [bmi],
        'children': [children],
        'smoker': [smoker],
        'region': [region]
    })
    
    # Ensure the input data is preprocessed consistently
    try:
        prediction = model.predict(input_data)
        return prediction[0]
    except Exception as e:
        return f"Error during prediction: {e}"
