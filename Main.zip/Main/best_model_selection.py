import pandas as pd
import numpy as np
import pickle  # For saving and loading the model
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression  # Replace with your selected model
from sklearn.preprocessing import StandardScaler

# 1. Load the dataset and rebuild the best model using 100% of the data
file_path = "Medical_insurance.csv"  # Update path if needed
medical_insurance_df = pd.read_csv(file_path) # Load the dataset
medical_insurance_df_cleaned = medical_insurance_df.drop_duplicates()
medical_insurance_df_numeric = pd.get_dummies(medical_insurance_df_cleaned, drop_first=True)

# Define features and target variable
X = medical_insurance_df_numeric.drop('charges', axis=1)
y = medical_insurance_df_numeric['charges']

# Retrain the best model (e.g., Linear Regression, replace with your best model)
model = LinearRegression()
model.fit(X, y)

# 2. Save the trained model as a serialized file
model_filename = 'best_model.pkl'
with open(model_filename, 'wb') as file:
    pickle.dump(model, file)

# 3. Create a prediction function that accepts inputs and returns a prediction
def predict_charges(age, sex, bmi, children, smoker, region):
    """
    Predicts medical charges based on input values.
    
    Parameters:
        age (int): Age of the individual
        sex (str): Gender of the individual ('male' or 'female')
        bmi (float): Body Mass Index
        children (int): Number of children/dependents
        smoker (str): Smoking status ('yes' or 'no')
        region (str): Region ('northeast', 'northwest', 'southeast', 'southwest')
        
    Returns:
        float: Predicted medical charges
    """
    # Rebuild the input data frame similar to the training data
    input_data = pd.DataFrame({
        'age': [age],
        'bmi': [bmi],
        'children': [children],
        'sex_male': [1 if sex == 'male' else 0],
        'smoker_yes': [1 if smoker == 'yes' else 0],
        'region_northwest': [1 if region == 'northwest' else 0],
        'region_southeast': [1 if region == 'southeast' else 0],
        'region_southwest': [1 if region == 'southwest' else 0]
    })

    # Load the saved model
    with open(model_filename, 'rb') as file:
        loaded_model = pickle.load(file)
    
    # Make the prediction
    prediction = loaded_model.predict(input_data)
    return float(prediction[0])

# Modified function to be used with the GUI
def run(df):
    output = []
    # Retrain the model using the provided dataframe
    df_cleaned = df.drop_duplicates()
    df_numeric = pd.get_dummies(df_cleaned, drop_first=True)
    
    X = df_numeric.drop('charges', axis=1, errors='ignore')
    if 'charges' in df_numeric:
        y = df_numeric['charges']
    else:
        return "Error: Target variable 'charges' not found."
    
    # Fit the model
    model.fit(X, y)
    with open(model_filename, 'wb') as file:
        pickle.dump(model, file)
    output.append(f"Model saved as {model_filename}.")
    
    # Example prediction for demonstration
    test_prediction = predict_charges(30, 'male', 25.0, 1, 'no', 'northeast')
    output.append(f"Test prediction for unseen data: ${test_prediction:.2f}")
    
    return "\n".join(output)
