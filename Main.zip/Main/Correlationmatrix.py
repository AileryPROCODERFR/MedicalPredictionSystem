import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats

# Load the dataset from your CSV file
file_path = "Medical_insurance.csv"  # Update this path to match your file location
medical_insurance_df = pd.read_csv(file_path)

# Remove duplicate rows
medical_insurance_df_cleaned = medical_insurance_df.drop_duplicates()

# Step 1: Convert Categorical Variables to Dummy Variables (One-Hot Encoding)
medical_insurance_df_encoded = pd.get_dummies(medical_insurance_df_cleaned, drop_first=True)

# Correlation analysis for continuous variables (excluding categorical features)
quantitative_columns = medical_insurance_df_encoded.select_dtypes(include=['float64', 'int64']).columns.tolist()
correlation_matrix = medical_insurance_df_encoded[quantitative_columns].corr()

# Plot correlation matrix for continuous variables only
plt.figure(figsize=(10, 6))
sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', fmt=".2f")
plt.title('Correlation Matrix (Continuous Variables)')
plt.show()

# Step 2: ANOVA Test for Categorical Variables
# Perform ANOVA for categorical variables vs. the target 'charges'
categorical_columns = ['sex', 'smoker', 'region']  # Keeping the original categorical columns
anova_results = {}

for column in categorical_columns:
    anova_groups = medical_insurance_df_cleaned.groupby(column)['charges'].apply(list)
    f_val, p_val = stats.f_oneway(*anova_groups)
    anova_results[column] = (f_val, p_val)

anova_df = pd.DataFrame(anova_results, index=["F-value", "p-value"]).T
print("\nANOVA Test Results:\n", anova_df)

# Display categorical variables that are statistically significant (p < 0.05)
significant_categorical = anova_df[anova_df["p-value"] < 0.05]
print("\nSignificant categorical features (p < 0.05):\n", significant_categorical)

# Step 3: Visualize the Relationship Between Region and Charges (Using Box Plot)
plt.figure(figsize=(10, 6))
sns.boxplot(x='region', y='charges', data=medical_insurance_df_cleaned)
plt.title('Box Plot of Charges by Region')
plt.ylabel('Charges ($)')
plt.xlabel('Region')
plt.grid(True)
plt.show()
