import pandas as pd

def run(df):
    output = []
    # Remove duplicate rows to clean up data
    df_cleaned = df.drop_duplicates()

    # Check for missing values
    output.append("Missing values before treatment:")
    output.append(str(df_cleaned.isnull().sum()))

    # Option 1: Delete rows with missing values if they are few
    # Uncomment the line below if you'd like to remove rows with missing values
    # df_cleaned = df_cleaned.dropna()

    # Option 2: Impute missing values with median for continuous variables
    continuous_columns = df_cleaned.select_dtypes(include=['float64', 'int64']).columns

    for column in continuous_columns:
        if df_cleaned[column].isnull().sum() > 0:
            median_value = df_cleaned[column].median()
            df_cleaned[column].fillna(median_value, inplace=True)
            output.append(f"Filled missing values in '{column}' with median value: {median_value}")

    # Option 3: Impute missing values with mode for categorical variables
    categorical_columns = df_cleaned.select_dtypes(include=['object']).columns

    for column in categorical_columns:
        if df_cleaned[column].isnull().sum() > 0:
            mode_value = df_cleaned[column].mode()[0]  # Get the most frequent value
            df_cleaned[column].fillna(mode_value, inplace=True)
            output.append(f"Filled missing values in '{column}' with mode value: {mode_value}")

    # Option 4: Interpolate missing values based on nearby values
    # Uncomment the line below to use interpolation
    # df_cleaned = df_cleaned.interpolate(method='linear')

    # Check for missing values again after treatment
    output.append("\nMissing values after treatment:")
    output.append(str(df_cleaned.isnull().sum()))

    # Display a sample of the cleaned data
    output.append("\nSample data after missing value treatment:")
    output.append(str(df_cleaned.head()))

    return "\n".join(output)
