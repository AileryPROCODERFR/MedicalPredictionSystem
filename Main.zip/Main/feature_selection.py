import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import io

def run(df):
    output = []
    # Remove duplicate rows to ensure clean data
    df_cleaned = df.drop_duplicates()

    # Define the target variable (dependent variable)
    target_variable = 'charges'

    # Step 1: Visual Analysis - Scatter plots for continuous vs. continuous variables
    continuous_columns = df_cleaned.select_dtypes(include=['float64', 'int64']).columns.tolist()
    if target_variable in continuous_columns:
        continuous_columns.remove(target_variable)

    plt.figure(figsize=(16, 10))
    for i, column in enumerate(continuous_columns, 1):
        plt.subplot(2, 3, i)
        sns.scatterplot(x=df_cleaned[column], y=df_cleaned[target_variable], color='skyblue')
        plt.title(f'Scatter Plot: {column} vs {target_variable}')
        plt.xlabel(column)
        plt.ylabel(target_variable)
    plt.tight_layout()
    plt.show()  # Display the scatterplots

    output.append("Scatter plots have been generated.")

    # Step 2: Statistical Correlation Analysis - Pearson's correlation
    correlation_matrix = df_cleaned[continuous_columns + [target_variable]].corr()
    output.append("\nPearson's Correlation Matrix:")
    output.append(str(correlation_matrix))

    # Step 3: Visual Analysis - Box plots for continuous vs. categorical variables
    categorical_columns = df_cleaned.select_dtypes(include=['object']).columns.tolist()

    plt.figure(figsize=(16, 10))
    for i, column in enumerate(categorical_columns, 1):
        plt.subplot(2, 3, i)
        sns.boxplot(x=column, y=target_variable, data=df_cleaned, palette='viridis', hue=column, legend=False)
        plt.title(f'Box Plot: {column} vs {target_variable}')
        plt.xlabel(column)
        plt.ylabel(target_variable)
    plt.tight_layout()
    plt.show()  # Display the boxplots

    output.append("Box plots have been generated.")

    return "\n".join(output)
