import pandas as pd

def run(df):
    output = []
    # Remove duplicate rows
    df_cleaned = df.drop_duplicates()

    # Step 1: Check for missing values
    output.append("Missing values before handling:")
    output.append(str(df_cleaned.isnull().sum()))

    # Step 2: Identify and Remove Outliers using the IQR method
    # Loop through each quantitative column to identify outliers
    quantitative_columns = df_cleaned.select_dtypes(include=['float64', 'int64']).columns

    for column in quantitative_columns:
        # Calculate Q1 (25th percentile) and Q3 (75th percentile)
        Q1 = df_cleaned[column].quantile(0.25)
        Q3 = df_cleaned[column].quantile(0.75)
        IQR = Q3 - Q1  # Interquartile Range

        # Define outlier bounds
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR

        # Remove outliers
        df_cleaned = df_cleaned[
            (df_cleaned[column] >= lower_bound) &
            (df_cleaned[column] <= upper_bound)
        ]

    # Step 3: Check for missing values again after removing outliers
    output.append("\nMissing values after handling outliers:")
    output.append(str(df_cleaned.isnull().sum()))

    # Step 4: Display the shape of the dataset before and after outlier removal
    output.append(f"\nOriginal dataset shape: {df.shape}")
    output.append(f"Dataset shape after outlier removal: {df_cleaned.shape}")

    # Step 5: Display a sample of the cleaned data
    output.append("\nSample data after outlier removal:")
    output.append(str(df_cleaned.head()))

    return "\n".join(output)
