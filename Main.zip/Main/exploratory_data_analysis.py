import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset from your CSV file
file_path = "Medical_insurance.csv"  # Update this path to match your file location
medical_insurance_df = pd.read_csv(file_path)

# Remove duplicate rows
medical_insurance_df_cleaned = medical_insurance_df.drop_duplicates()

# Identify quantitative and categorical columns
quantitative_columns = medical_insurance_df_cleaned.select_dtypes(include=['float64', 'int64']).columns.tolist()
categorical_columns = medical_insurance_df_cleaned.select_dtypes(include=['object']).columns.tolist()

# Set up the figure for plotting histograms of quantitative variables
plt.figure(figsize=(16, 20))
for i, column in enumerate(quantitative_columns, 1):
    plt.subplot(len(quantitative_columns), 1, i)
    sns.histplot(medical_insurance_df_cleaned[column], bins=20, kde=True, color='skyblue')
    plt.title(f'Distribution of {column}')
    plt.xlabel(column)
    plt.ylabel('Frequency')
    plt.grid(True)

# Show histograms for quantitative variables
plt.tight_layout()
plt.show()

# Set up the figure for plotting bar charts of categorical variables
plt.figure(figsize=(16, 20))
for i, column in enumerate(categorical_columns, 1):
    plt.subplot(len(categorical_columns), 1, i)
    sns.countplot(data=medical_insurance_df_cleaned, x=column, palette='viridis')
    plt.title(f'Distribution of {column}')
    plt.xlabel(column)
    plt.ylabel('Count')
    plt.grid(True, axis='y')

# Show bar charts for categorical variables
plt.tight_layout()
plt.show()
